#   Complete student management system with classes, sorting,
#   updating, and error handling.

class Student:
    def __init__(self,name,maths,english,science):
        self.name=name
        self.maths=maths
        self.english=english
        self.science=science

    def print_student(self):
        avg= (self.maths+self.english+self.science)/3
        print(self.name)
        print("Maths:",self.maths)
        print("English:",self.english)
        print("Science:",self.science)
        print("Average:",avg)

    def update_student(self,subject,new_value):
        subject=subject.lower()
        if subject == 'maths':
            self.maths=new_value
        elif subject == 'english':
            self.english=new_value
        elif subject == 'science':
            self.science=new_value
        else:
            print('Invalid subject')
            return
        print("grade has been updated")

    def show_average(self):
        return(self.maths+self.english+self.science)/3

class Gradebook:
    def __init__(self):
        self.students={}

    def add_student(self):
        try:
            student_number = int(input("Enter the number of students in the class: "))
        except ValueError:
            print('Invalid input')
            return
        for i in range(student_number):
            name = input("Enter the student name : ")
            while name == "":
                name = input("Enter the student name : ")

            maths = float(input("Enter maths grade(0-100): "))
            while maths > 100 or maths < 0:
                print("Grade must be between 0 and 100")
                maths = float(input("Enter maths grade(0-100): "))

            english = float(input("Enter english grade(0-100): "))
            while english > 100 or english < 0:
                print("Grade must be between 0 and 100")
                english = float(input("Enter english grade(0-100): "))

            science = float(input("Enter science grade(0-100): "))
            while science > 100 or science < 0:
                print("Grade must be between 0 and 100")
                science = float(input("Enter science grade(0-100): "))
            #dictionaries
            self.students[name] = Student(name,maths,english,science)
            print(name,"added!")

#students and their grades+averages
    def all_students(self):
        print("All student names and grades")
        if len(self.students) == 0:
            print("No student names")
        else:
            for name in self.students:
                print(name)
            print()

#search
    def search_student(self):
        search_name=input("Enter the student name to search for: ")
        if search_name in self.students:
            print(search_name,"'s grades:", self.students[search_name])
        else :
            print("Sorry, the student name you entered doesn't exist.")

#removing students
    def remove_student(self):
        confirm=input("Remove student name from list? (y/n): ").lower()
        if confirm=="y":
            remove = input("Enter the student name to remove: ")
            if remove in self.students:
                del self.students[remove]
                print([remove],"removed successfully")
            else:
                print("Student not found")
        if confirm == "n":
            print("Thank you,goodbye")

#update students
    def update_student(self):
        student=input("Enter the student name to update: ")
        if student in self.students:
            subject = input("Enter the subject you would like to update(maths, english, science): ").lower()
            if subject in ["maths", "english", "science"]:
                new = int(input("Enter the new grade(0-100): "))
                while new>100 or new<0:
                    print("Grade must be between 0 and 100")
                    new = int(input("Enter the new grade(0-100): "))
                self.students[subject] = new
                print("Updated successfully")
            else:
                print("Subject not found")
        else:
            print("Student not found")

#sorting students
    def sort_students(self):
        if len(self.students) == 0:
            print("No students to sort.")
            return
        student_list = list(self.students.values())
        student_list.sort(key=lambda s: s.show_average(), reverse=True)
        for s in student_list:
            s.print_student()

    def top_student(self):
        if len(self.students) == 0:
            print("No students yet.")
            return
        top = max(self.students.values(), key=lambda s: s.show_average())
        print("Top Student")
        top.print_student()

gradebook=Gradebook()

while True:
    print("----MENU----")
    print("1. Add students")
    print("2. View students")
    print("3. Search students")
    print("4. Update student grades")
    print("5. Sort students by average")
    print("6. View top student")
    print("7. Remove students")
    print("8. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        gradebook.add_student()
    elif choice == "2":
        gradebook.all_students()
    elif choice == "3":
        gradebook.search_student()
    elif choice == "4":
        gradebook.update_student()
    elif choice == "5":
        gradebook.sort_students()
    elif choice == "6":
        gradebook.top_student()
    elif choice == "7":
        gradebook.remove_student()
    elif choice == "8":
        print("Thank you,goodbye")
        break
    else:
        print("Invalid choice")

#testing documentation
#add Student
#Input: 2 students (oratile 90,85,95 and sebaga 60,70,65)
#Expected Output: "oratile added!" and "sebaga added!"

#Viewing All Students
#Input: Choice = 2
#Expected Output: Lists each student’s subject marks and average.

#Update Grades
#Input: Choice = 4, Name = sebaga, Subject = Maths, New = 75
# Expected Output: "Grade updated successfully!"

#Sort Students
#Input: Choice = 5
#Expected Output: Students displayed in descending average order.

#View Top Student
#Input: Choice = 6
#Expected Output: Displays highest average student.

#Remove Student
#Input: Choice = 7, Name = sebaga
# Expected Output: "sebaga removed successfully."
