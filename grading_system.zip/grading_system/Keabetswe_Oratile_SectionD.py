#   Introduces functions for adding, viewing, searching,
#   and removing students. Uses a looping menu for control.

students={}

def add_students():
    name = input("Enter the student name : ")
    maths = float(input("Enter maths grade(0-100): "))
    while maths>100 or maths<0:
        print("Grade must be between 0 and 100")
        maths = float(input("Enter maths grade(0-100): "))

    english = float(input("Enter english grade(0-100): "))
    while english > 100 or english < 0:
        print("Grade must be between 0 and 100")
        english = float(input("Enter english grade(0-100): "))

    science = float(input("Enter science grade(0-100): "))
    while science > 100 or science < 0:
        print("Grade must be between 0 and 100")
        science = float(input("Enter science grade(0-100): "))
#dictionaries
    students[name] = {
        "maths": maths,
        "english": english,
        "science": science
    }
#students and their grades+averages
def all_students():
    print("All student names and grades:")
    if students == 0:
        print("No student names")
    else:
        for name in students:
            print(name,":", students[name])
            print()

#search
def search_student():
    search_name=input("Enter the student name to search for: ")
    if search_name in students:
        print(search_name,"'s grades:", students[search_name])
    else :
        print("Sorry, the student name you entered doesn't exist.")

#removing students
def remove_student():
    choice=input("Remove student name from list? (y/n): ").lower()
    if choice=="y":
        remove = input("Enter the student name to remove: ")
        if remove in students:
           del students[remove]
           print([remove],"removed successfully")
        else:
           print("Student not found")
    if choice == "n":
       print("Thank you,goodbye")

while True:
    print("----MENU----")
    print("1. Add students")
    print("2. View students")
    print("3. Search students")
    print("4. Remove students")
    print("5. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        student_number = int(input("Enter the number of students in the class: "))
        for i in range(student_number):
            add_students()
    elif choice == "2":
        all_students()
    elif choice == "3":
        search_student()
    elif choice == "4":
        remove_student()
    elif choice == "5":
        print("Thank you,goodbye")
        break
    else:
        print("Invalid choice")


#testing documentation
#main menu
#Input: 1 → add student, 2 → view, 5 → exit
# Expected Output: All options respond correctly.

#add Student
# Input: oratile, Maths 90, English 85, Science 95
# Expected Output: "oratile added successfully!"

#search
# Input: "arona"
# Expected Output: "Student not found."
#
#remove Student
# Input: y → "oratile"
# Expected Output: "oratile removed successfully."