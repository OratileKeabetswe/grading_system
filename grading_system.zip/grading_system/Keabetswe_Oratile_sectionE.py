#   Introduces object-oriented programming using Student and
#   Gradebook classes to organize student data and actions.

class Student:
    def __init__(self,name,maths,english,science):
        self.name=name
        self.maths=maths
        self.english=english
        self.science=science

    def print_student(self):
        print(self.name,self.maths,self.english,self.science)

    def update_student(self,subject,new_value):
        subject=subject.lower()
        if subject == 'maths':
            self.maths=new_value
        elif subject == 'english':
            self.english=new_value
        elif subject == 'science':
            self.science=new_value
        else:
            print('Invalid subject')
            return
        print("grade has been updated")

class Gradebook:
    def __init__(self):
        self.students={}

    def add_student(self):
        try:
            student_number = int(input("Enter the number of students in the class: "))
        except ValueError:
            print('Invalid input')
            return
        for i in range(student_number):
            name = input("Enter the student name : ")
            while name == "":
                name = input("Enter the student name : ")

            maths = float(input("Enter maths grade(0-100): "))
            while maths > 100 or maths < 0:
                print("Grade must be between 0 and 100")
                maths = float(input("Enter maths grade(0-100): "))

            english = float(input("Enter english grade(0-100): "))
            while english > 100 or english < 0:
                print("Grade must be between 0 and 100")
                english = float(input("Enter english grade(0-100): "))

            science = float(input("Enter science grade(0-100): "))
            while science > 100 or science < 0:
                print("Grade must be between 0 and 100")
                science = float(input("Enter science grade(0-100): "))
            #dictionaries
            self.students[name] = {"maths": maths,"english": english,"science": science}
            print(name,"added!")

#students and their grades+averages
    def all_students(self):
        print("All student names and grades:")
        if len(self.students) == 0:
            print("No student names")
        else:
            for name in self.students:
                print(name,":", self.students[name])
            print()

#search
    def search_student(self):
        search_name=input("Enter the student name to search for: ")
        if search_name in self.students:
            print(search_name,"'s grades:", self.students[search_name])
        else :
            print("Sorry, the student name you entered doesn't exist.")

#removing students
    def remove_student(self):
        confirm=input("Remove student name from list? (y/n): ").lower()
        if confirm=="y":
            remove = input("Enter the student name to remove: ")
            if remove in self.students:
                del self.students[remove]
                print([remove],"removed successfully")
            else:
                print("Student not found")
        if confirm == "n":
            print("Thank you,goodbye")

    def update_student(self):
        student=input("Enter the student name to update: ")
        if student in self.students:
            subject = input("Enter the subject you would like to update(maths, english, science): ").lower()
            if subject in ["maths", "english", "science"]:
                new = int(input("Enter the new grade(0-100): "))
                while new>100 or new<0:
                    print("Grade must be between 0 and 100")
                    new = int(input("Enter the new grade(0-100): "))
                self.students[subject] = new
                print("Updated successfully")
            else:
                print("Subject not found")
        else:
            print("Student not found")
gradebook=Gradebook()

while True:
    print("----MENU----")
    print("1. Add students")
    print("2. View students")
    print("3. Search students")
    print("4. Update student grades")
    print("5. Remove students")
    print("6. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        gradebook.add_student()
    elif choice == "2":
        gradebook.all_students()
    elif choice == "3":
        gradebook.search_student()
    elif choice == "4":
        gradebook.update_student()
    elif choice == "5":
        gradebook.remove_student()
    elif choice == "6":
        print("Thank you,goodbye")
        break
    else:
        print("Invalid choice")

#testing documentation
#add Student
#input: arona, Maths 90, English 80, Science 70
#expected Output: "arona added!"

# search Student
# Input: "arona"
# Expected Output: Displays Maths, English, Science marks.

#remove Student
# Input: "arona"
# Expected Output: "Removed successfully."
