#   The program asks for the number of students, records each
#   student's name and grades in three subjects,
#   validates all grade inputs (0–100),
#   then calculates individual and class averages.

#subject definition
subjects = ["maths","english","science"]

#number of students
student_number = int(input("Enter the number of students in the class: "))
while student_number <= 0:
    print("Please enter at least 1 student.")
    student_number = int(input("Enter the number of students in the class: "))

#total initialization
maths_total = 0
english_total = 0
science_total = 0

#looping through each student
for i in range(student_number):
    print("Student #", i + 1)
    name= input("Enter the student name : ")

 #maths
    maths = float(input("Enter maths grade(0-100): "))

    while maths>100 or maths<0:
        print("Grade must be between 0 and 100")
        maths = float(input("Enter maths grade(0-100): "))

#english
    english = float(input("Enter english grade(0-100): "))

    while english > 100 or english < 0:
        print("Grade must be between 0 and 100")
        english = float(input("Enter english grade(0-100): "))

#science
    science = float(input("Enter science grade(0-100): "))
    while science > 100 or science < 0:
        print("Grade must be between 0 and 100")
        science = float(input("Enter science grade(0-100): "))

#class averages(highest and lowest)
    average = maths + english + science
    print("Name:",name,"Average grade:", average)

#class totals
    maths_total = maths_total + maths
    english_total = english_total + english
    science_total = science_total + science
    print()

#display class subject averages
print("maths average:", maths_total/student_number)
print("english average:", english_total/student_number)
print("science average:", science_total/student_number)

#testing documentation
#inputs
# number of students: 2
# oratile: Maths 80, English 90, Science 100
# sebaga 2: Maths 70, English 60, Science 50

#expected output
#correct individual averages and subject averages.

#grade valid (e.g., 120)
# program repeats prompt until valid input is given.