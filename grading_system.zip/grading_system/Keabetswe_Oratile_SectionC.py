#   Uses a dictionary to store multiple students and their grades.
#   Allows searching, removing, and calculating averages.

students={}

student_number = int(input("Enter the number of students in the class: "))

#add students
for i in range(student_number):
    print("Student #", i + 1)
    name= input("Enter the student name : ")

 #maths
    maths = float(input("Enter maths grade(0-100): "))

    while maths>100 or maths<0:
        print("Grade must be between 0 and 100")
        maths = float(input("Enter maths grade(0-100): "))

#english
    english = float(input("Enter english grade(0-100): "))

    while english > 100 or english < 0:
        print("Grade must be between 0 and 100")
        english = float(input("Enter english grade(0-100): "))

#science
    science = float(input("Enter science grade(0-100): "))
    while science > 100 or science < 0:
        print("Grade must be between 0 and 100")
        science = float(input("Enter science grade(0-100): "))

#dictionaries
    students[name] = {
        "maths": maths,
        "english": english,
        "science": science
    }

#students and their grades+averages
print("All student names and grades:")
for name in students:
    print(name,":", students[name])
    print()

maths_total = 0
english_total = 0
science_total = 0

for name in students:
    maths_total = students[name]["maths"]
    english_total = students[name]["english"]
    science_total = students[name]["science"]
print("---Average scores----")
print("maths average:", maths_total / student_number)
print("english average:", english_total / student_number)
print("science average:", science_total / student_number)
print()

#search
while True:
    search_name=input("Enter the student name to search for: ")
    if search_name in students:
        print(search_name,"'s grades:", students[search_name])
        break
    else :
        print("Sorry, the student name you entered doesn't exist.")

#removing students
choice=input("Remove student name from list? (y/n): ").lower()
if choice=="y":
    remove = input("Enter the student name to remove: ")
    if remove in students:
        del students[remove]
        print([remove],"removed successfully")
    else:
        print("Student not found")
if choice == "n":
       print("Thank you,goodbye")
print()

#updated list
print("Student names and grades(updated):")
for name in students:
    print(name,":", students[name])
    print()

#averages
maths_total = 0
english_total = 0
science_total = 0

for name in students:
    maths_total = students[name]["maths"]
    english_total = students[name]["english"]
    science_total = students[name]["science"]
    print()
print("---Average scores----")
print("maths average:", maths_total / student_number)
print("english average:", english_total / student_number)
print("science average:", science_total / student_number)

#testing documentation
# Input:
#   Number of students: 2
#   Student 1: oratile → Maths 90, English 80, Science 70
#   Student 2: sebaga → Maths 60, English 65, Science 75
# Expected Output:
#   Displays both students and their subject grades.

#search test
# Input:
#   search_name = "oratile"
# Expected Output:
#   oratile’s grades printed.

#searching for invalid student
# Input:
#   search_name = "arona"
# Expected Output:
#   "Sorry, that student doesn't exist."

#removing students
# Input:
#   choice = y, remove = "sebaga"
# Expected Output:
#"sebaga removed successfully." Then only oratile remains.