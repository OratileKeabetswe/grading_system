#the program collects the number of students in class
# the student's name
# student's grades
# calculates the class average

#number of students
student_number = int(input("Enter the number of students in the class:"))
total=0

#loops through students
for i in range(student_number):
    name = input("Enter student name: ")
    #grade validation
    grade = float(input("Enter grade(0-100): "))
    while grade >100 or grade < 0:
        print("Grade must be between 0 and 100.")
        grade = float(input("Enter grade(0-100): "))
    #output
    print("Name: ", name)
    print("Grade: ", grade)

    #adding grade to total to calculate class average
    total = total + grade

#calculate and display average
average = total / student_number
print(" Class Average: ", average)


#testing documentation
# inputs
#number of students:2
#name:Oratile,Sebaga
#grade:70,30

#expected outputs
#Name:Oratile
#Grade:70
#Name:Sebaga
#Grade:30
#Class average:50.0

#grade valid (e.g., 120)
# program repeats prompt until valid input is given.